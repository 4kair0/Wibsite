const cheetas = document.querySelectorAll('.cheeta')
window.addEventListener('scroll',checkcheetas)
checkcheetas()
function checkcheetas(){
const triggerBottom = window.innerHeight / 5 * 4
cheetas.forEach(cheeta =>{
    const cheetaTop = cheeta.getBoundingClientRect().top
    if(cheetaTop < triggerBottom){
        cheeta.classList.add('show')
    }
    else{
        cheeta.classList.remove('show')
    }
})
}